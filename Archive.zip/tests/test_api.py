import pytest
import pytest_asyncio
from httpx import AsyncClient, ASGITransport

from app.main import app


@pytest_asyncio.fixture
async def client():

    transport = ASGITransport(app=app)

    async with AsyncClient(
        transport=transport,
        base_url="http://test",
    ) as client:

        yield client


async def test_get_books(client):

    response = await client.get("/books")

    assert response.status_code == 200


@pytest.mark.parametrize(
    "booklist,response_code",
    [
        (
            [
                {
                    "book_title": "Atomic Habits",
                    "author": "James Clear",
                }
            ],
            201,
        ),
    ],
)
async def test_create_books(
    client,
    booklist,
    response_code,
):

    response = await client.post(
        "/books",
        json=booklist,
    )

    assert response.status_code == response_code